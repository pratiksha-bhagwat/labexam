package com.hotel.reservation.services;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.reservation.entities.Reservation;
import com.hotel.reservation.entities.Room;
import com.hotel.reservation.repositories.ReservationRepository;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomService roomService;

    public Reservation createReservation(String guestName, Date checkInDate, Date checkOutDate, Long roomId) {
        Room room = roomService.getRoomById(roomId);
        if (room != null && room.isAvailability()) {
            double totalPrice = room.getPrice();
            Reservation reservation = new Reservation(guestName, checkInDate, checkOutDate, roomId, totalPrice);
            roomService.updateRoomAvailability(roomId, false); // Mark room as unavailable
            return reservationRepository.save(reservation);
        }
        return null;
    }

    public String cancelReservation(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId).get();
        if (reservation!=null) {
            reservationRepository.delete(reservation);
            return "Reservation cancelled successfully.";
        }
        else {
        	throw new RuntimeException("Not Found");
        }
    }
}
