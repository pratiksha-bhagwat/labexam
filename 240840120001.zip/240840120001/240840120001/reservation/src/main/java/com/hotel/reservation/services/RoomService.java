package com.hotel.reservation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.reservation.entities.Room;
import com.hotel.reservation.repositories.RoomRepository;

import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailabilityTrue();
    }

    public Room getRoomById(Long roomId) {
        return roomRepository.findById(roomId).orElse(null);
    }

    public Room updateRoomAvailability(Long roomId, boolean availability) {
        Room room = getRoomById(roomId);
        if (room != null) {
            room.setAvailability(availability);
            return roomRepository.save(room);
        }
        return null;
    }
}
