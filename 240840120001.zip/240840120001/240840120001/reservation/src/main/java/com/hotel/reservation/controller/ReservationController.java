package com.hotel.reservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hotel.reservation.dto.ReservationRequest;
import com.hotel.reservation.entities.Reservation;
import com.hotel.reservation.entities.Room;
import com.hotel.reservation.services.ReservationService;
import com.hotel.reservation.services.RoomService;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private RoomService roomService;

    // Create a reservation
    @PostMapping
    public Reservation createReservation(@RequestBody ReservationRequest request) {
        return reservationService.createReservation(
                request.getGuestName(),
                request.getCheckInDate(),
                request.getCheckOutDate(),
                request.getRoomId()
        );
    }

    // Get all available rooms
    @GetMapping("/rooms")
    public List<Room> getAvailableRooms() {
        return roomService.getAvailableRooms();
    }

    // Cancel reservation
    @DeleteMapping("/{reservationId}")
    public String cancelReservation(@PathVariable Long reservationId) {
        return reservationService.cancelReservation(reservationId);
    }
}
