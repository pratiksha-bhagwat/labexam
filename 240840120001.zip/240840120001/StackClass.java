public class StackClass implements StackI {
    private int[] stack;
    private int[] minStack;
    private int top;

    public StackClass(int capacity) {
        stack = new int[capacity];
        minStack = new int[capacity];
        top = -1;
    }

    @Override
    public void push(int x) {
        if (top == stack.length - 1) {
            throw new StackOverflowError("Stack is full");
        }
        top++;
        stack[top] = x;
        if (top == 0) {
            minStack[top] = x;
        } else {
            minStack[top] = Math.min(x, minStack[top - 1]);
        }
    }

    @Override
    public void pop() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }
        top--;
    }

    @Override
    public int top() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }
        return stack[top];
    }

    @Override
    public int min() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }
        return minStack[top];
    }
}
