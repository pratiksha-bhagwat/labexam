public class Main {
    public static void main(String[] args) {
        StackI stack = new StackClass(10);

        stack.push(5);
        stack.push(2);
        stack.push(8);
        stack.push(1);

        System.out.println("Top element: " + stack.top());  
        System.out.println("Minimum element: " + stack.min());  

        stack.pop();

        System.out.println("Top element: " + stack.top());  
        System.out.println("Minimum element: " + stack.min());  
    }
}
