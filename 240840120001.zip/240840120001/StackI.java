public interface StackI {
    void push(int x); 
    void pop();      
    int top();        
    int min();        
}
